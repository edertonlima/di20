<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/pt-br:Editando_wp-config.php
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações
// com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define('DB_NAME', 'di20_novo');

/** Usuário do banco de dados MySQL */
define('DB_USER', 'di20_novo');

/** Senha do banco de dados MySQL */
define('DB_PASSWORD', 'rR8vVlY2xoM2Vwwc');

/** Nome do host do MySQL */
define('DB_HOST', 'localhost');

/** Charset do banco de dados a ser usado na criação das tabelas. */
define('DB_CHARSET', 'utf8mb4');

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define('DB_COLLATE', '');

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'vL(TX-)y6]u,-7<A$JA wf=MJbdNs(#ol%Jy/Q6T3-uv3@v5iMh(D;V4783z~&gJ');
define('SECURE_AUTH_KEY',  ')wm$KuBPIA}!SF:@{pw#n}M8F7a#EK0|7YxKV&Xe@w|g8qf$<j{95O~1dOi<Z5ta');
define('LOGGED_IN_KEY',    'hq(3@Zs4m`0Zx99 MaQ&9}+]EV]V81e>H2,gd1l!p*07bFA;pt`e2V+r0vp&.$qB');
define('NONCE_KEY',        '@x$gHhY{C,2|yM=q}9nSsO yl2*sf# /G)*)`53tQ/ &SI#9^=`/51L!$?))iR@1');
define('AUTH_SALT',        'qN;DWk_o)+I_spfiAJ:[1F!+`.HXCMe`{@P57&E7hRSLt*Z zz~>OFnT:,0tjE+ ');
define('SECURE_AUTH_SALT', '.+9A;.Xq$6WY}D(E{Cb)xpOe1<~4CxX{n[fP(`+LX!x_~,(^M7:L~Bq1[OJibF~:');
define('LOGGED_IN_SALT',   'b,P^]grHl[LQ:7$X`%J8CMKuR#K+D&-=-hqYRT%4wj<W #02qPj`KVcne<9c?C,[');
define('NONCE_SALT',       '8W$0XB/IgGRQcfUeO-9HBuJdP~cI][ z*FRP}w/ics9=EH!A`I5]l; hk2(Q8X$E');

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix  = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://codex.wordpress.org/pt-br:Depura%C3%A7%C3%A3o_no_WordPress
 */
define('WP_DEBUG', false);

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Configura as variáveis e arquivos do WordPress. */
require_once(ABSPATH . 'wp-settings.php');
